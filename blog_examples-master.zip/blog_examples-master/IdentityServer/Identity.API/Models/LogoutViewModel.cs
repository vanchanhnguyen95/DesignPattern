﻿namespace Identity.API.Models
{
    public class LogoutViewModel
    {
        public string LogoutId { get; set; }
    }
}
